<?php
	// exec("E:");
	// system("cd project");
	// system("cd webapp");
	// system("cd apidoc");

	// exec("apidoc -i project/webapp/apidoc/example/ -o project/webapp/apidoc/doc/ -t project/webapp/apidoc/template/");
	// exec("apidoc -i example/ -o doc/ -t template/",$out);
// exec('calc');
		// exec("mkdir E:\\test\\test",$out);
		// print_r($out);
// exec("apidoc -i E:\\project\\webapp\\apidoc\\example\\ -o E:\\project\\webapp\\apidoc\\doc\\ -t E:\\project\\webapp\\apidoc\\template\\");

	// system("E:");
	// system("apidocs.bat");

// system('cmd E:\\apidocs.bat');
// 		apidoc -i E:\\project\\webapp\\apidoc\\example\\ -o E:\\project\\webapp\\apidoc\\doc\\ -t project/webapp/apidoc/template/


// apidoc -i example/ -o doc/ -t template/


system("E:\\apidocs.bat", $info);

echo $info;
?>


