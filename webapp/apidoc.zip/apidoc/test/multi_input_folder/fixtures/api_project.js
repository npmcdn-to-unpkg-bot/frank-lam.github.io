define({
  "name": "Multiple Input Folder Test",
  "version": "1.0.0",
  "description": "Example of feeding apidoc from multiple input folder locations",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2015-05-08T13:05:54.193Z",
    "url": "http://apidocjs.com",
    "version": "0.12.3"
  }
});
