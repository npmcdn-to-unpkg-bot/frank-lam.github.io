define({ "api": [
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=privilege_add",
    "title": "特权add",
    "description": "<p>特权add</p>",
    "group": "ATT_privilege",
    "name": "privilege_add",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "type",
            "description": "<p>特权类型 not null</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>特权名称 not null</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "validity",
            "description": "<p>特权有效期（天） not null</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "msg",
            "description": "<p>特权说明</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/index.php/Home/User/?action=privilege_add&t_start=2016-08-03&t_stop=2016-08-03",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "r",
            "description": "<p>success:1,fail:0</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "msg",
            "description": ""
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "ATT_privilege",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=privilege_add"
      }
    ]
  },
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=privilege_del",
    "title": "特权删除",
    "description": "<p>特权删除</p>",
    "group": "ATT_privilege",
    "name": "privilege_del",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "id",
            "description": ""
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://www.ifrank.loan/index.php/Home/User/?action=privilege_del",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "ATT_privilege",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=privilege_del"
      }
    ]
  },
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=privilege_list",
    "title": "特权list",
    "description": "<p>特权list</p>",
    "group": "ATT_privilege",
    "name": "privilege_list",
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/index.php/Home/User/?action=privilege_list",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "id",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "type",
            "description": "<p>特权类型</p>"
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "name",
            "description": "<p>特权名称</p>"
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "validity",
            "description": "<p>特权有效期（天）</p>"
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "msg",
            "description": "<p>特权说明</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "ATT_privilege",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=privilege_list"
      }
    ]
  },
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=privilege_trans",
    "title": "特权修改",
    "description": "<p>特权修改</p>",
    "group": "ATT_privilege",
    "name": "privilege_trans",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "type",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "validity",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "msg",
            "description": ""
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://www.ifrank.loan/index.php/Home/User/?action=privilege_trans",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "ATT_privilege",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=privilege_trans"
      }
    ]
  },
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=user_pri_add",
    "title": "用户特权添加",
    "description": "<p>用户特权添加</p>",
    "group": "ATT_privilege",
    "name": "user_pri_add",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "cardid",
            "description": "<p>用户工号</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "privilege_id",
            "description": "<p>特权id</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://www.ifrank.loan/index.php/Home/User/?action=user_pri_add",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "ATT_privilege",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=user_pri_add"
      }
    ]
  },
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=user_pri_del",
    "title": "用户特权删除",
    "description": "<p>用户特权删除</p>",
    "group": "ATT_privilege",
    "name": "user_pri_del",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "id",
            "optional": false,
            "field": "id",
            "description": "<p>用户特权id</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://www.ifrank.loan/index.php/Home/User/?action=user_pri_del",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "ATT_privilege",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=user_pri_del"
      }
    ]
  },
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=user_pri_list",
    "title": "用户特权",
    "description": "<p>用户特权</p>",
    "group": "ATT_privilege",
    "name": "user_pri_list",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "start",
            "description": "<p>默认0</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "limit",
            "description": "<p>默认20</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "userid",
            "description": "<p>用户名查询</p>"
          },
          {
            "group": "Parameter",
            "type": "date",
            "optional": false,
            "field": "time_add_start",
            "description": "<p>特权获得时间</p>"
          },
          {
            "group": "Parameter",
            "type": "date",
            "optional": false,
            "field": "time_add_stop",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>特权名</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "validity",
            "description": "<p>有效期</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "status",
            "description": "<p>特权状态1：可用；2：过期</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "order",
            "description": "<p>排序字段</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "seq",
            "description": "<p>排序方式</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://www.ifrank.loan/index.php/Home/User/?action=user_pri_list",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "ATT_privilege",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=user_pri_list"
      }
    ]
  },
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=att_check_in",
    "title": "重置att_check表数据",
    "description": "<p>重置att_check表数据</p>",
    "group": "ATT",
    "name": "att_check_in",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Date",
            "optional": false,
            "field": "t_start",
            "description": "<p>开始时间，格式例如：2016-08-03</p>"
          },
          {
            "group": "Parameter",
            "type": "Date",
            "optional": false,
            "field": "t_stop",
            "description": "<p>结束时间，格式例如：2016-08-03</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/index.php/Home/User/?action=att_check_in&t_start=2016-08-03&t_stop=2016-08-03",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "ATT",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=att_check_in"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=getAttRank",
    "title": "每日上班打卡排名",
    "description": "<p>获取每日上班打卡排名</p>",
    "group": "ATT",
    "name": "getAttRank",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "userid",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "date",
            "optional": false,
            "field": "date",
            "description": "<p>时间，格式例如：2016-08-03</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": true,
            "field": "top",
            "description": "<p>排名TOP数量，不传值则选择所有</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "order",
            "description": "<p>排序类型，am上班打卡pm下班打卡</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=getAttRank",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "ATT",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=getAttRank"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=initLoginLog",
    "title": "初始化登录日志",
    "description": "<p>初始化登录日志</p>",
    "group": "ATT",
    "name": "initLoginLog",
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=initLoginLog",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "ATT",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=initLoginLog"
      }
    ]
  },
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=book_index",
    "title": "书目录查询",
    "description": "<p>书目录查询</p>",
    "group": "BOOK",
    "name": "book_index",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "ISBN13",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "ISBN10",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>书名</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name_en",
            "description": "<p>英文名</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "author",
            "description": "<p>作者</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "inventory_max",
            "description": "<p>库存:min=&lt;x&lt;max</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "inventory_min",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "inventory_r_max",
            "description": "<p>可借</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "inventory_r_min",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "bookshelf_max",
            "description": "<p>书架号</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "bookshelf_min",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "checktime_max",
            "description": "<p>入库时间</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "pages_size_min",
            "description": "<p>页数</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "public_date",
            "description": "<p>出版时间</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "order",
            "description": "<p>排序</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "seq",
            "description": "<p>排序方式0：倒序；1：正序</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://www.ifrank.loan/index.php/Home/User/?action=book_index",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "BOOK",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=book_index"
      }
    ]
  },
  {
    "type": "post",
    "url": "/index.php/Home/User/?action=bor_rank",
    "title": "借书排行",
    "description": "<p>借书排行</p>",
    "group": "BOOK",
    "name": "bor_rank",
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://www.ifrank.loan/index.php/Home/User/?action=bor_rank",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "cardid",
            "description": "<p>工号</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>姓名</p>"
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "rank",
            "description": "<p>借阅量</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/UserController.class.php",
    "groupTitle": "BOOK",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/index.php/Home/User/?action=bor_rank"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=book_application",
    "title": "购书申请",
    "description": "<p>普通用户提交自己的购书申请</p>",
    "group": "Book",
    "name": "book_application",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "isbn",
            "description": "<p>图书13位ISBN</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "bookurl",
            "description": "<p>购买图书参考链接</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "purchase_reason",
            "description": "<p>购书申请理由</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "userid",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "btnswitch",
            "description": "<p>是否要短信通知</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "mobile",
            "description": "<p>通知手机号</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=book_application",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "code",
            "description": "<p>1-成功，0-失败</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "msg",
            "description": "<p>返回提示信息</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "Book",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=book_application"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=getBookApplyList",
    "title": "购书申请审核列表",
    "description": "<p>获取购书申请审核的列表</p>",
    "group": "Book",
    "name": "getBookApplyList",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "status",
            "description": "<p>0：未审核，1：已审核，2：所有购书申请</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "page",
            "description": "<p>页码数</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "size",
            "description": "<p>每页数据长度</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=getBookApplyList",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "total",
            "description": "<p>status选定状态的总条数</p>"
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "page",
            "description": "<p>页码</p>"
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "size",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "pagersize",
            "description": "<p>总页数</p>"
          },
          {
            "group": "Success 200",
            "type": "int",
            "optional": false,
            "field": "count",
            "description": "<p>当前页的数量，如最后一页的时候不一定达到size大小</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "r",
            "description": "<p>返回详细信息</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sql",
            "description": "<p>sql查询语句</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "Book",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=getBookApplyList"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=delWeixinInfo",
    "title": "重置att_userinfo微信信息",
    "description": "<p>数据库att_userinfo开关</p>",
    "group": "Switch",
    "name": "addWeixinInfo",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "userid",
            "description": "<p>用户名</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=delWeixinInfo",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>返回码，1成功，0失败</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "msg",
            "description": "<p>错误信息</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "Switch",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=delWeixinInfo"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=getBookinfo",
    "title": "",
    "description": "<p>获取图书信息</p>",
    "group": "User",
    "name": "getBookinfo",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "book_id",
            "description": "<p>图书数据库id编号</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=getBookinfo",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "JSON",
            "optional": false,
            "field": "JsonStr",
            "description": "<p>返回JSON数据</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "User",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=getBookinfo"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=getInfoByUserid",
    "title": "通过userid获取用户信息",
    "description": "<p>通过userid获取用户信息</p>",
    "group": "User",
    "name": "getInfoByUserid",
    "version": "0.1.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "userid",
            "description": "<p>用户名</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=getInfoByUserid",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "data",
            "description": "<p>json数组对象</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "User",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=getInfoByUserid"
      }
    ]
  },
  {
    "type": "post",
    "url": "/Home/Page?action=getUserInfoByUserid",
    "title": "",
    "description": "<p>获取图书信息</p>",
    "group": "User",
    "name": "getUserInfoByUserid",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "book_id",
            "description": "<p>图书数据库id编号</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=getUserInfoByUserid",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "JSON",
            "optional": false,
            "field": "JsonStr",
            "description": "<p>返回JSON数据</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/PageController.class.php",
    "groupTitle": "User",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/Home/Page?action=getUserInfoByUserid"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=login",
    "title": "用户登录",
    "description": "<p>用户登录</p>",
    "group": "User",
    "name": "login",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "userid",
            "description": "<p>账号</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "password",
            "description": "<p>密码</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=login",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>返回码，1成功，0失败</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "msg",
            "description": "<p>错误信息</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "User",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=login"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=tryLoginWeixin",
    "title": "登录微信授权",
    "description": "<p>如果已经绑定微信，则第二次直接跳转到个人中心页面</p>",
    "group": "WEIXIN2",
    "name": "addWeixinInfo",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "openid",
            "description": "<p>openid</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=tryLoginWeixin",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>返回码，1成功，0失败</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "msg",
            "description": "<p>提示信息</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "userid",
            "description": "<p>返回openid对应的账号</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "WEIXIN2",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=tryLoginWeixin"
      }
    ]
  },
  {
    "type": "post",
    "url": "/?action=addWeixinInfo",
    "title": "微信信息添加",
    "description": "<p>添加微信信息到用户表</p>",
    "group": "WEIXIN",
    "name": "addWeixinInfo",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "userid",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "openid",
            "description": "<p>openid</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "headimgurl",
            "description": "<p>头像</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "nickname",
            "description": "<p>昵称</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sex",
            "description": "<p>性别</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "country",
            "description": "<p>国家</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "province",
            "description": "<p>省</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "city",
            "description": "<p>市</p>"
          }
        ]
      }
    },
    "version": "0.1.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://hzrrkj.gnway.cc:8080/?action=addWeixinInfo",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>返回码，1成功，0失败</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "msg",
            "description": "<p>错误信息</p>"
          }
        ]
      }
    },
    "filename": "F:/webapp/Application/Home/Controller/IndexController.class.php",
    "groupTitle": "WEIXIN",
    "sampleRequest": [
      {
        "url": "http://att.renrunkeji.cn/?action=addWeixinInfo"
      }
    ]
  }
] });
