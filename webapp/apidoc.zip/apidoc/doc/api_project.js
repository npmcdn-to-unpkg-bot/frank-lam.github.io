define({
  "name": "仁润员工在线社区（考勤、图书）",
  "version": "0.3.0",
  "description": "webapp 1.0 接口说明文档",
  "title": "接口文档",
  "url": "http://att.renrunkeji.cn",
  "sampleUrl": "http://att.renrunkeji.cn",
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "footer": {
    "title": "APIDOC注释使用说明",
    "content": "<p>#代码注释#\n<br/>\n中文使用说明:<a href=\"http://www.jianshu.com/p/bb5a4f5e588a\" target=\"blank\">http://www.jianshu.com/p/bb5a4f5e588a</a>\n<br/>\ngithub:<a href=\"https://github.com/apidoc/apidoc\" target=\"blank\">https://github.com/apidoc/apidoc</a></p>\n"
  },
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-08-10T08:34:32.770Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
