define({
  "name": "example",
  "version": "0.3.0",
  "description": "apidoc example project.",
  "apidoc": "0.2.0",
  "sampleUrl": false,
  "generator": {
    "name": "apidoc",
    "time": "2016-08-04T11:07:18.083Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
